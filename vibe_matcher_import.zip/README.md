# Vibe Matcher Prototype

This folder structure is ready for GitHub import.
You can upload directly to your repository.

Contents:
- vibe_matcher_notebook.ipynb
- requirements.txt
- README.md
